var searchData=
[
  ['firmware_5fversion',['firmware_version',['../structdevice__info.html#af3d369a410577d85ec6b59ffeeaade48',1,'device_info']]],
  ['frequency',['frequency',['../structscan__frequency.html#ae4f2152e77416cff02f44452355f2808',1,'scan_frequency']]]
];
