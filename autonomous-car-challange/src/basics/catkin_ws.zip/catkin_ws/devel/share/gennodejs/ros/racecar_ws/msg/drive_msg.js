// Auto-generated. Do not edit!

// (in-package racecar_ws.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class drive_msg {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.drive_angle = null;
      this.velocity = null;
      this.acceleration = null;
      this.fallbakc = null;
    }
    else {
      if (initObj.hasOwnProperty('drive_angle')) {
        this.drive_angle = initObj.drive_angle
      }
      else {
        this.drive_angle = 0.0;
      }
      if (initObj.hasOwnProperty('velocity')) {
        this.velocity = initObj.velocity
      }
      else {
        this.velocity = 0.0;
      }
      if (initObj.hasOwnProperty('acceleration')) {
        this.acceleration = initObj.acceleration
      }
      else {
        this.acceleration = 0.0;
      }
      if (initObj.hasOwnProperty('fallbakc')) {
        this.fallbakc = initObj.fallbakc
      }
      else {
        this.fallbakc = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type drive_msg
    // Serialize message field [drive_angle]
    bufferOffset = _serializer.float32(obj.drive_angle, buffer, bufferOffset);
    // Serialize message field [velocity]
    bufferOffset = _serializer.float32(obj.velocity, buffer, bufferOffset);
    // Serialize message field [acceleration]
    bufferOffset = _serializer.float32(obj.acceleration, buffer, bufferOffset);
    // Serialize message field [fallbakc]
    bufferOffset = _serializer.string(obj.fallbakc, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type drive_msg
    let len;
    let data = new drive_msg(null);
    // Deserialize message field [drive_angle]
    data.drive_angle = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [velocity]
    data.velocity = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [acceleration]
    data.acceleration = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [fallbakc]
    data.fallbakc = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.fallbakc.length;
    return length + 16;
  }

  static datatype() {
    // Returns string type for a message object
    return 'racecar_ws/drive_msg';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'dde1342e4fc7143d4551f76581f10abb';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float32 drive_angle
    float32 velocity
    float32 acceleration
    string fallbakc
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new drive_msg(null);
    if (msg.drive_angle !== undefined) {
      resolved.drive_angle = msg.drive_angle;
    }
    else {
      resolved.drive_angle = 0.0
    }

    if (msg.velocity !== undefined) {
      resolved.velocity = msg.velocity;
    }
    else {
      resolved.velocity = 0.0
    }

    if (msg.acceleration !== undefined) {
      resolved.acceleration = msg.acceleration;
    }
    else {
      resolved.acceleration = 0.0
    }

    if (msg.fallbakc !== undefined) {
      resolved.fallbakc = msg.fallbakc;
    }
    else {
      resolved.fallbakc = ''
    }

    return resolved;
    }
};

module.exports = drive_msg;
